package repop1_jafethou;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class RepoP1_JafetHou {

    static Scanner leer = new Scanner(System.in);

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);

        boolean continuar = true;
        while (continuar) {
            System.out.println("1. Encriptacion simple");
            System.out.println("2. Tokens");
            System.out.println("3. Inicio de sesion");
            System.out.println("4. Ingrese 4 para salir");
            System.out.println("Ingrese la opcion:");
            int OPC = leer.nextInt();

            switch (OPC) {
                case 1: {
                    System.out.print("Ingrese la cadena que desea encriptar: ");
                    String cadena = leer.next();

                    System.out.print("Ingrese la llave (entre 1 y 10): ");
                    int llave = leer.nextInt();

                    String cadenaEncrip = encriptar(cadena, llave);
                    System.out.println("La cadena encriptada es: " + cadenaEncrip);

                    break;
                }
                case 2: {

                    System.out.print("Ingrese la cadena: ");
                    String cadena = leer.next();

                    System.out.print("Ingrese el caracter: ");
                    char separador = leer.next().charAt(0);

                    String[] palabrasSep = separarCad(cadena, separador);
                    System.out.println("Resultado: ");
                    for (String palabra : palabrasSep) {
                        System.out.print("[" + palabra + "] ");
                    }
                    System.out.println("");

                    break;
                }
                case 3: {

                    String[] arregloID = crearArregloID();
                    String[] arregloContra = crearArregloContra();

                    System.out.println("Arreglos creados:");
                    System.out.println("arregloID = " + java.util.Arrays.toString(arregloID));
                    System.out.println("arregloContra = " + java.util.Arrays.toString(arregloContra));

                    System.out.print("Ingrese el ID del usuario: ");
                    String idUsuario = leer.next();

                    System.out.print("Ingrese la contrasena: ");
                    String contrasena = leer.next();

                    boolean autenticacion = false;

                    for (int i = 0; i < arregloID.length; i++) {
                        if (arregloID[i].equals(idUsuario) && arregloContra[i].equals(contrasena)) {
                            autenticacion = true;
                            break;
                        }
                    }

                    if (autenticacion == true) {
                        System.out.println("La autenticacion fue exitosa");
                    } else {
                        System.out.println("Error, el usuario y la contrasena no son las mismas");       
                    }
                    
                    break;
                }
                case 4:{
                    continuar = false;
                    break;
                }
                default: {
                    break;
                }

            }
        }

    }

    public static String encriptar(String texto, int clave) {
        StringBuilder resultado = new StringBuilder();
        int indiceIn = texto.charAt(0) % 2 == 0 ? clave : -clave;
        if (clave > 0 && clave < 11) {
            for (int i = 0; i < texto.length(); i++) {
                char caracter = texto.charAt(i);
                char caracterEncrip = (char) (caracter + indiceIn);
                resultado.append(caracterEncrip);
            }
        } else {
            System.out.println("La llave debe ser mayor a mayor o igual a 1 y menor o igual a 10");
        }

        return resultado.toString();
    }

    public static String[] separarCad(String cadena, char separador) {
        List<String> resultado = new ArrayList<>();
        StringBuilder palabraAct = new StringBuilder();

        for (int i = 0; i < cadena.length(); i++) {
            char caracter = cadena.charAt(i);

            if (caracter != separador) {
                palabraAct.append(caracter);
            } else {
                resultado.add(palabraAct.toString());
                palabraAct = new StringBuilder();
            }
        }

        resultado.add(palabraAct.toString());

        return resultado.toArray(new String[0]);
    }

    public static String[] crearArregloID() {
        String[] arregloID = {"usuario1", "persona", "otro85"};
        return arregloID;
    }

    public static String[] crearArregloContra() {
        String[] arregloContra = {"123", "abcd12", "qwerty11"};
        return arregloContra;
    }
}
